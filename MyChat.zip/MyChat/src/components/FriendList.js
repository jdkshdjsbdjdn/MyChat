import React, { useState, useEffect } from 'react';
import { collection, query, where, getDocs, addDoc } from 'firebase/firestore';
// Doğru import yolu: components klasöründesin, firebase klasörü bir üstte
import { db } from '../firebase/firestore';

// 'firestore' değişkenini ayrıca import etmene gerek yok, zaten 'db' var
// import { firestore } from '../firebase/firestore';  // Bunu kaldır

function FriendList({ user, selectedFriend, setSelectedFriend }) {
  const [friends, setFriends] = useState([]);
  const [searchEmail, setSearchEmail] = useState('');
  const [error, setError] = useState('');

  useEffect(() => {
    const fetchFriends = async () => {
      const friendsRef = collection(db, 'users', user.uid, 'friends');
      const snapshot = await getDocs(friendsRef);
      const friendList = snapshot.docs.map(doc => doc.data());
      setFriends(friendList);
    };

    fetchFriends();
  }, [user.uid]);

  const addFriend = async () => {
    setError('');
    if (!searchEmail.trim()) return;

    if (searchEmail === user.email) {
      setError('Kendini ekleyemezsin.');
      return;
    }

    try {
      const usersRef = collection(db, 'users');
      const q = query(usersRef, where('email', '==', searchEmail));
      const querySnapshot = await getDocs(q);

      if (querySnapshot.empty) {
        setError('Kullanıcı bulunamadı.');
        return;
      }

      const friendData = querySnapshot.docs[0].data();

      const friendsRef = collection(db, 'users', user.uid, 'friends');
      await addDoc(friendsRef, {
        uid: friendData.uid,
        email: friendData.email,
      });

      setFriends(prev => [...prev, { uid: friendData.uid, email: friendData.email }]);
      setSearchEmail('');
    } catch (err) {
      setError('Bir hata oluştu: ' + err.message);
    }
  };

  return (
    <div className="w-64 bg-gray-900 p-4 flex flex-col">
      <h2 className="text-lg font-bold mb-2">Arkadaşlar</h2>
      <div className="flex gap-2 mb-4">
        <input
          type="email"
          placeholder="E-posta ile ara"
          value={searchEmail}
          onChange={(e) => setSearchEmail(e.target.value)}
          className="flex-grow p-2 rounded bg-gray-700 border border-gray-600 text-white"
        />
        <button
          onClick={addFriend}
          className="bg-green-500 hover:bg-green-600 px-3 rounded font-bold"
        >
          Ekle
        </button>
      </div>
      {error && <p className="text-red-400 text-sm mb-2">{error}</p>}
      <div className="flex-grow overflow-y-auto">
        {friends.length === 0 && <p>Arkadaş bulunamadı.</p>}
        {friends.map(friend => (
          <div
            key={friend.uid}
            onClick={() => setSelectedFriend(friend)}
            className={`p-2 rounded cursor-pointer ${
              selectedFriend?.uid === friend.uid ? 'bg-green-700' : 'hover:bg-gray-700'
            }`}
          >
            {friend.email}
          </div>
        ))}
      </div>
    </div>
  );
}

export default FriendList;
