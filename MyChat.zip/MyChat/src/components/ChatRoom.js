import React, { useState, useEffect, useRef } from 'react';
import { collection, query, orderBy, onSnapshot, addDoc, serverTimestamp } from 'firebase/firestore';
// Burada 'db' değişkenini src/firebase/firestore.js dosyasından import etmelisin
import { db } from '../firebase/firestore';

import FriendList from './FriendList';
import CallInterface from './CallInterface';

// 'firestore' isimli import muhtemelen gereksiz, zaten 'db' kullanıyorsun. İstersen kaldırabilirsin.
// import { firestore } from '../firebase/firestore'; 

function ChatRoom({ user }) {
  const [messages, setMessages] = useState([]);
  const [input, setInput] = useState('');
  const [selectedFriend, setSelectedFriend] = useState(null);
  const messagesEndRef = useRef(null);

  useEffect(() => {
    if (!selectedFriend) return;

    const messagesRef = collection(db, 'chats', getChatId(user.uid, selectedFriend.uid), 'messages');
    const q = query(messagesRef, orderBy('createdAt', 'asc'));

    const unsubscribe = onSnapshot(q, (snapshot) => {
      const msgs = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() }));
      setMessages(msgs);
      scrollToBottom();
    });

    return () => unsubscribe();
  }, [selectedFriend, user.uid]);

  const getChatId = (uid1, uid2) => {
    return uid1 > uid2 ? uid1 + '_' + uid2 : uid2 + '_' + uid1;
  };

  const sendMessage = async (e) => {
    e.preventDefault();
    if (!input.trim()) return;
    if (!selectedFriend) return;

    const messagesRef = collection(db, 'chats', getChatId(user.uid, selectedFriend.uid), 'messages');
    await addDoc(messagesRef, {
      text: input,
      sender: user.uid,
      createdAt: serverTimestamp(),
    });
    setInput('');
  };

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  return (
    <div className="flex w-full max-w-6xl h-screen bg-gray-800 text-white">
      <FriendList
        user={user}
        selectedFriend={selectedFriend}
        setSelectedFriend={setSelectedFriend}
      />

      <div className="flex flex-col flex-grow p-4">
        {selectedFriend ? (
          <>
            <div className="flex justify-between items-center border-b border-gray-600 pb-2">
              <h2 className="text-xl font-bold">{selectedFriend.email}</h2>
              <CallInterface user={user} friend={selectedFriend} />
            </div>

            <div className="flex-grow overflow-y-auto mt-4 mb-2">
              {messages.map(msg => (
                <div
                  key={msg.id}
                  className={`mb-2 max-w-xs p-2 rounded ${
                    msg.sender === user.uid ? 'bg-green-600 self-end' : 'bg-gray-700 self-start'
                  }`}
                >
                  {msg.text}
                </div>
              ))}
              <div ref={messagesEndRef} />
            </div>

            <form onSubmit={sendMessage} className="flex gap-2">
              <input
                type="text"
                value={input}
                onChange={e => setInput(e.target.value)}
                placeholder="Mesaj yaz..."
                className="flex-grow p-2 rounded bg-gray-700 text-white border border-gray-600"
              />
              <button
                type="submit"
                className="bg-green-500 px-4 rounded hover:bg-green-600 font-bold"
              >
                Gönder
              </button>
            </form>
          </>
        ) : (
          <div className="flex-grow flex items-center justify-center text-gray-400">
            Arkadaş seç ve sohbete başla!
          </div>
        )}
      </div>
    </div>
  );
}

export default ChatRoom;
