import React, { useState } from 'react';
import { signInWithEmailAndPassword, createUserWithEmailAndPassword } from 'firebase/auth';
import { auth } from '../firebase/auth';

function AuthForm() {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [isRegistering, setIsRegistering] = useState(false);
  const [error, setError] = useState('');

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      if (isRegistering) {
        await createUserWithEmailAndPassword(auth, email, password);
      } else {
        await signInWithEmailAndPassword(auth, email, password);
      }
    } catch (err) {
      setError(err.message);
    }
  };

  return (
    <div className="bg-gray-800 p-6 rounded-lg shadow-lg w-80">
      <h2 className="text-xl font-bold mb-4">{isRegistering ? 'Kayıt Ol' : 'Giriş Yap'}</h2>
      <form onSubmit={handleSubmit} className="flex flex-col gap-4">
        <input
          type="email"
          placeholder="E-posta"
          value={email}
          onChange={(e) => setEmail(e.target.value)}
          required
          className="p-2 rounded bg-gray-700 border border-gray-600 text-white"
        />
        <input
          type="password"
          placeholder="Şifre"
          value={password}
          onChange={(e) => setPassword(e.target.value)}
          required
          className="p-2 rounded bg-gray-700 border border-gray-600 text-white"
        />
        <button
          type="submit"
          className="bg-green-500 hover:bg-green-600 text-white font-bold py-2 rounded"
        >
          {isRegistering ? 'Kayıt Ol' : 'Giriş Yap'}
        </button>
        <p
          onClick={() => setIsRegistering(!isRegistering)}
          className="text-sm text-blue-400 hover:underline cursor-pointer text-center"
        >
          {isRegistering
            ? 'Zaten bir hesabın var mı? Giriş yap.'
            : 'Hesabın yok mu? Kayıt ol.'}
        </p>
        {error && <p className="text-red-400 text-sm text-center">{error}</p>}
      </form>
    </div>
  );
}

export default AuthForm;
