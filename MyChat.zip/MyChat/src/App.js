import React, { useState, useEffect } from 'react';
import AuthForm from './components/AuthForm';
import ChatRoom from './components/ChatRoom';
import { auth } from './firebase/auth';
import { onAuthStateChanged } from 'firebase/auth';

function App() {
  const [user, setUser] = useState(null);

  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, setUser);
    return () => unsubscribe();
  }, []);

  return (
    <div className="bg-gray-900 text-white min-h-screen">
      {user ? (
        <ChatRoom user={user} />
      ) : (
        <AuthForm />
      )}
    </div>
  );
}

export default App;
