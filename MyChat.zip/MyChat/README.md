Projeye hoş geldin!

Başlamak için # Başlatmak için dosyasına gir. Orada lazım olan bilgi var.

Kolay gelsin! Bol şanslar! (Lazım olacak...)

