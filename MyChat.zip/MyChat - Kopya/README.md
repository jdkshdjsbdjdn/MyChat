İndirdiğiniz için teşekkürler!



Başlamak için 'LAUNCHER.bat' dosyasını çalıştırın.

BİLGİ: Eğer ilk kurulum esnasında programı kapatırsanız, temizlik ayarları (2. seçenek) ile node\_module dosyasını silmeniz gereklidir. (1. seçenek)

